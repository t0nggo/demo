import { TransfPipe } from './transf.pipe';

describe('TransfPipe', () => {
  it('create an instance', () => {
    const pipe = new TransfPipe();
    expect(pipe).toBeTruthy();
  });
});
